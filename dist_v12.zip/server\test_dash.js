import http from 'http';
http.get('http://localhost:4000/api/teachers/t1/dashboard', (res) => {
  let data = '';
  res.on('data', chunk => data += chunk);
  res.on('end', () => console.log('Response:', data));
}).on('error', err => console.error('Error:', err.message));
